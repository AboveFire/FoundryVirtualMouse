# Foundry-JS-virtual-Touchpad
Its like having a mouse in your mobile browser. 

# Basic functionality
This project provides a basic emulation of a laptop touchpad that can be overlayed over an application designed for desktop use. The touchpad shows up as a mostly transparent overlay over your web application.

# Credits
Most of the code from this module is taken from this virtual mouse:
https://github.com/mmiscool/JS-virtual-Touchpad